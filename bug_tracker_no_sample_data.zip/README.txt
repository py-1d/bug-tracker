Bug Tracker Source Files

Files included:
- index.html
- styles.css
- script.js

Open index.html in a browser to run the app.
